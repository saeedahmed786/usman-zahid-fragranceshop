import React, { useEffect, useState } from 'react'
import styles from './Navbar.module.css'
import Link from 'next/link'
import { logout } from '../Auth/auth'
import { DownOutlined, LockOutlined, LogoutOutlined, MenuOutlined, UserOutlined } from '@ant-design/icons'
import { Drawer, Dropdown, Space } from 'antd'
import LogoComp from '../LogoComp/LogoComp'

export const Navbar = () => {
  const [user, setUser] = useState({});
  const [open, setOpen] = useState(false);
  const showDrawer = () => {
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
  };

  useEffect(() => {
    setUser(JSON.parse(localStorage.getItem("user")));

    return () => {

    }
  }, [])

  const items = [
    {
      key: '1',
      label: (
        <a href="/" onClick={() => logout()}>
          Cerrar Sesión
        </a>
      ),
    }
  ];
  console.log(user);
  return (
    <nav className={styles.Navbar}>
      <div className={styles.upper}>
        <div className={styles.left}>
          <div className={styles.logo}>
            <Link href="/">
              <LogoComp />
            </Link>
          </div>
        </div>
        <div className={styles.right}>
          {
            user ?
              <div className={'flex items-center gap-3 ' + styles.loginRegBtn}>
                {
                  user?.role === 1 &&
                  <Link href="/admin" className='text-center'> <LockOutlined /> < br /> <span>Dashboard</span></Link>
                }
                <Link href="/profile" className='text-center'> <UserOutlined /> < br /> <span>Account</span></Link>
                <a href="/login" className='text-center'> <LogoutOutlined /> < br /> <span>Logout</span></a>
              </div>
              :
              <div className={`flex items-center gap-2 md:gap-10 text-white`}>
                <Link href="/login" className='text-center'> <UserOutlined /> < br /> <span>Account</span></Link>
              </div>
          }
        </div>
      </div>
      <div className={styles.mobileMenu}>
        <button onClick={showDrawer} className="text-white"><MenuOutlined className='text-[19px]' /></button>
      </div>
      <Drawer title={<div className='flex justify-end items-center gap-2'><UserOutlined />{user && <span>Hola!,{user?.fullName}</span>}</div>} width={300} placement="right" onClose={onClose} open={open}>
        <div className='text-end'>
          <div>
            <Link href="/">Inicio</Link>
          </div>
          <div>
            <Link href="/services">Servicios</Link>
          </div>
          <div>
            <Link href="/pricing">Planes</Link>
          </div>
          <div>
            <Link href="/meet-victoria">Conoce a Victoria</Link>
          </div>
          <div>
            <Link href="/">Contacto</Link>
          </div>
          {
            user ?
              <div className='flex mt-4 justify-end items-center gap-2'>
                <button className=''>{user?.fullName}</button>
                <a href="/" onClick={() => logout(() => { })}>Cerrar Sesión</a>
              </div>
              :
              <div className={`flex mt-4 justify-end items-center gap-2 md:gap-10 text-black ${styles.signupBtn}`}>
                <Link href="/login">Login</Link>
              </div>
          }
        </div>
      </Drawer>
    </nav >
  )
}
