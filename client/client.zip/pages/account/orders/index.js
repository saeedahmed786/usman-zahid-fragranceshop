import { AccountLayout } from '@/components/Layouts/AccountLayout/AccountLayout'
import React from 'react'

const Profile = () => {
    return (
        <AccountLayout sidebar>
            Orders
        </AccountLayout>
    )
}

export default Profile
