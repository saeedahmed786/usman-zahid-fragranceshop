import AdminLayout from '@/components/Layouts/Admin/AdminLayout'
import React from 'react'

const Admin = () => {
    return (
        <AdminLayout sidebar>
            Admin
        </AdminLayout>
    )
}

export default Admin
