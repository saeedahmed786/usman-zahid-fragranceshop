import React from 'react'
import AdminLayout from '../layouts/Admin/AdminLayout'

const Admin = () => {
    return (
        <AdminLayout sidebar>
            Admin
        </AdminLayout>
    )
}

export default Admin
