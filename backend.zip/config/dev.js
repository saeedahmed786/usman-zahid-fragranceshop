module.exports = {
    mongoURI: 'mongodb://localhost:27017/FragranceShop',
    jwtSecret: 'kdjkasjqr8239r8kfj939kdjkdjfkwt944039043kjgkwjgkwgwlkg404204wegklgkt42-owpglw4-y34pyo3py0239tfkeit049igkjkvjvw049t09tofjkwrjt034tigdfkjgkdfjg0rt9304fsdkfj04t904gigo',
    jwtExpire: '24h',
    cloudinary_cloud_name: 'saeedahmed',
    cloudinary_api_key: '633615861791628',
    cloudinary_api_secret: 'pcu5hDuFK01arwcxuotN3EHXFRc',
    EMAIL: 'ali9656623@gmail.com',
    PASSWORD: "dnrdgeoodzullmnp",
    stripe_secret: "sk_test_51Jx0u1G6FnU8wwE5kHioRqyVvSs5Rb7A7cdoUq5GjTEtQigQqyydie8y4uoeiHFpu1GebWTXmaSdoDSDp1TIpJAX00QuBqPq96",
    chatEncryptionSecret: "jqwdjqnwdiwehirueiru382ru24ur9ewjfcdnjwncf2u49rtu924ufiwjedhe2f92u4t924"
} 
